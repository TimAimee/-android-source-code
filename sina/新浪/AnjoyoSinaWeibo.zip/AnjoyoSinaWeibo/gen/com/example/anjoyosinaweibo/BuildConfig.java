/** Automatically generated file. DO NOT MODIFY */
package com.example.anjoyosinaweibo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}