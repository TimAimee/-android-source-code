package com.lance.tablinepagerindictor;

import java.util.List;

import com.lance.tablinepagerindictor.data.ContentStruct;
import com.lance.tablinepagerindictor.data.TitleStruct;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ContentFrameAdapter extends FragmentPagerAdapter{

	private List<TitleStruct> mTitleList;
	private List<ContentStruct> mContentList;
	
	public ContentFrameAdapter(FragmentManager fm) {
		super(fm);

	}
	
	
	public void setContentList(List<ContentStruct> list){
		mContentList = list;
	}
	
	public void setTitleList(List<TitleStruct> list){
		mTitleList = list;
	}

	@Override
	public Fragment getItem(int pos) {
		// TODO Auto-generated method stub
		if (mContentList == null){
			return null;
		}
		return ContentFrame.newInstance(mContentList.get(pos));
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if (mContentList != null){
			return mContentList.size();
		}else{
			return 0;
		}
	}


	@Override
	public CharSequence getPageTitle(int position) {
		if (mTitleList != null){
			return mTitleList.get(position).toString();
		}
		return super.getPageTitle(position);
	}
	
	

}
