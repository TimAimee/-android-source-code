package com.lance.tablinepagerindictor;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.Window;

import com.lance.tablinepagerindictor.data.ContentStruct;
import com.lance.tablinepagerindictor.data.TitleStruct;
import com.lance.tablinepagerindictor.widget.UnderlinePageIndicatorEx;
import com.viewpagerindicator.TabPageIndicator;


/**
 *  @author: lance
 *  @csdn_blog: http://blog.csdn.net/geniuseoe2012 
 *  @android_develop_group ：298044305
 */
public class MainActivity extends FragmentActivity {

	private ContentFrameAdapter mContentAdapter;
	private ViewPager mPager;
	private TabPageIndicator mTabPageIndicator;
	private UnderlinePageIndicatorEx mUnderlinePageIndicator;
	
	
	private  int COUNT = 0;
	private List<TitleStruct> mTitleList;
	private List<ContentStruct> mContentList;
	
	
	

	@Override
	protected void onCreate(Bundle arg0) {

		super.onCreate(arg0);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.activity_main);
		
		initData();
		setupViews();

	}


	private void setupViews(){		
	     
	     mPager = (ViewPager)findViewById(R.id.pager);
		 mPager.setAdapter(mContentAdapter); 
		
	     mTabPageIndicator = (TabPageIndicator) findViewById(R.id.tab_indicator);   
	     mTabPageIndicator.setViewPager(mPager);     
	     
	     mUnderlinePageIndicator = (UnderlinePageIndicatorEx)findViewById(R.id.underline_indicator);
	     mUnderlinePageIndicator.setViewPager(mPager);
	     mUnderlinePageIndicator.setFades(false);
	     
	     mTabPageIndicator.setOnPageChangeListener(mUnderlinePageIndicator);
	}
	
	
	private void initData(){
		 mContentList = new ArrayList<ContentStruct>();
		 mTitleList = new ArrayList<TitleStruct>();
		
		 String[] arrStrings = getResources().getStringArray(R.array.sections);
	     COUNT = arrStrings.length;
         for (int i = 0; i < COUNT; i++) {
        	 ContentStruct object = new ContentStruct();
        	 object.daString = arrStrings[i];
        	 object.index = i;      
        	 mContentList.add(object);
        	 
        	 TitleStruct object2 = new TitleStruct(arrStrings[i]);
        	 mTitleList.add(object2);
         }
         
    	 
		 mContentAdapter = new ContentFrameAdapter(getSupportFragmentManager());
	     mContentAdapter.setContentList(mContentList);
	     mContentAdapter.setTitleList(mTitleList);
   
	}

}
