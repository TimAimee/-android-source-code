package com.lance.tablinepagerindictor;


import com.lance.tablinepagerindictor.data.ContentStruct;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ContentFrame extends Fragment{

	private ContentStruct mStruct;
	
	public ContentFrame(ContentStruct struct){
		mStruct = struct;
	}
	
	public static ContentFrame newInstance(ContentStruct object){
		return new ContentFrame(object);
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {


		View view = inflater.inflate(R.layout.layout1, null);
		TextView tView = (TextView) view.findViewById(R.id.textView);
		tView.setText(mStruct.toString());
		
		return view;
	}

}
