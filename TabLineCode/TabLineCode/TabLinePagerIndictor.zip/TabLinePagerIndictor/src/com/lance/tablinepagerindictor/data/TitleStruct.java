package com.lance.tablinepagerindictor.data;

public class TitleStruct {

	public String daString = "";
	
	public TitleStruct(String title){
		daString = title;
	}

	public String toString(){
		return daString;
	}
}
